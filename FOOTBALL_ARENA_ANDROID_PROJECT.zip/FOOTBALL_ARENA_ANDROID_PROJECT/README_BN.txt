FOOTBALL ARENA Android project
================================
এই ZIP-এ একটি Android WebView অ্যাপ প্রজেক্ট আছে। অ্যাপের ভেতরে assets/www/index.html
থেকে বর্তমান Dark Premium UI চালু হবে।

APK build:
1. ZIP extract করে সব ফাইল GitHub repository root-এ upload করুন (পুরোনো README রেখে দিতে পারেন)।
2. GitHub > Actions > Build FOOTBALL ARENA APK > Run workflow।
3. সফল হলে Artifacts থেকে FOOTBALL-ARENA-APK ডাউনলোড করুন।

গুরুত্বপূর্ণ:
- এটি প্রথম Android shell / debug APK ভিত্তি। Play Store release-এর জন্য signed release build,
  privacy policy, app icon, testing এবং Play Console সেটআপ লাগবে।
- Login, cloud database, real live scores, payment, push notification এবং secure admin API
  এই প্যাকেজে এখনো নেই। একই account/data-এর জন্য পরে shared backend যোগ করতে হবে।
- নমুনা ম্যাচের তথ্য ডেমো; বাস্তব লাইভ স্কোর নয়।
